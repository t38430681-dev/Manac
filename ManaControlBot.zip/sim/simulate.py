"""Simulador do mini game Mana Control para ajustar/validar o controlador.
Unidades normalizadas: largura da zona = 1.0. e = (centro da zona - anel). Meta: e ~ 0.
Planta: segurar -> zona encolhe (vH<0); soltar -> expande (vR>0); latencia de toque;
surtos: saltos bruscos de tamanho a cada 3-8 s; ruido de medicao; alvo com deriva.
O controlador e o mesmo algoritmo do app (Controller.kt)."""
import random, math, sys

class Controller:
    def __init__(s):
        s.vH=-0.9; s.vR=0.6          # estimativas iniciais (largura/s) - aprendidas online
        s.e=0.0; s.ve=0.0; s.acc=0.0; s.cmd=0
        s.kp=7.0; s.kd=0.0; s.last=None; s.hist=[]
        s.lat=0.05
    def learn(s,dt,e):
        # estimativa de velocidade e RLS simples: de/dt = comando previo
        if s.last is not None:
            v=(e-s.last)/dt
            s.ve=0.6*s.ve+0.4*v
            if abs(v)<4:  # ignora surtos (saltos)
                if s.cmd==1: s.vH+=0.02*(v-s.vH)
                else: s.vR+=0.02*(v-s.vR)
                s.vH=min(s.vH,-0.15); s.vR=max(s.vR,0.15)
        s.last=e
    def step(s,dt,e):
        s.learn(dt,e)
        ep=e+s.ve*s.lat*1.0                       # predicao pela latencia
        vstar=-s.kp*ep                              # velocidade desejada
        # velocidade media do alvo vem do proprio ve (feedforward ja em ep)
        duty=(vstar-s.vR)/(s.vH-s.vR)
        duty=max(0.0,min(1.0,duty))
        if abs(e)>0.55: duty=1.0 if e>0 else 0.0   # saturacao apos surto
        s.acc+=duty
        if s.acc>=1.0: s.acc-=1.0; s.cmd=1
        else: s.cmd=0
        return s.cmd

def run(seed,T=120,dt=1/60,vH=-0.9,vR=0.6,lat=0.05,noise=0.015,skip=0.0):
    random.seed(seed)
    c=Controller(); c.lat=lat
    x=0.0   # e verdadeiro
    q=[0]*int(lat/dt+1)
    nxt=random.uniform(3,8); inb=0; n=0; inz=0; tdrift=0; last=-9
    for i in range(int(T/dt)):
        t=i*dt
        if t>=nxt:
            x+=random.choice([-1,1])*random.uniform(0.25,0.9); nxt=t+random.uniform(3,8); last=t
        tdrift=0.15*math.sin(t*1.7)*dt*8+random.gauss(0,0.01)*math.sqrt(dt)*10
        meas=x+random.gauss(0,noise)
        cmd=c.step(dt,meas)
        q.append(cmd); applied=q.pop(0)
        x+=(vH if applied else vR)*dt+tdrift*dt*10
        if t>1.0 and t-last>skip:
            n+=1
            if abs(x)<0.5: inz+=1       # dentro da zona (meia largura)
            if abs(x)<0.25: inb+=1      # no meio (metade central)
    return inz/n, inb/n

if __name__=="__main__":
    cfgs=[dict(),dict(vH=-1.5,vR=1.0),dict(vH=-0.6,vR=0.4,lat=0.08),dict(vH=-2.0,vR=1.5,lat=0.03)]
    for name,skip in (("incluindo recuperacao de surtos",0.0),("regime estavel (1 s apos surto)",1.0)):
        r=[run(sd,skip=skip,**c) for sd in range(20) for c in cfgs]
        print(f"{name}: dentro da zona {sum(a for a,b in r)/len(r)*100:.2f}% | metade central {sum(b for a,b in r)/len(r)*100:.2f}%")
