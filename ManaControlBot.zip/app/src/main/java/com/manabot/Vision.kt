package com.manabot

import java.nio.ByteBuffer
import kotlin.math.*

data class Measure(val e: Double, val width: Double, val cx: Int, val cy: Int)

/** Le o frame RGBA e mede a faixa pale (zona) e o anel lavanda, normalizando por raio/largura. */
object Vision {
    private const val RAYS = 36

    private fun px(buf: ByteBuffer, w: Int, h: Int, stride: Int, pxStride: Int, x: Int, y: Int, out: IntArray) {
        val o = y * stride + x * pxStride
        out[0] = buf.get(o).toInt() and 255; out[1] = buf.get(o + 1).toInt() and 255; out[2] = buf.get(o + 2).toInt() and 255
    }
    private fun isBand(r: Int, g: Int, b: Int) = abs(r - 182) < 16 && abs(g - 142) < 16 && abs(b - 183) < 16
    private fun isRing(r: Int, g: Int, b: Int) = r > 200 && b > 222 && g in 150..222 && (b - g) > 38

    fun measure(buf: ByteBuffer, w: Int, h: Int, rowStride: Int, pixelStride: Int): Measure? {
        val c = IntArray(3)
        // 1) centro = centroide dos pixels da faixa (grade esparsa na regiao central)
        var sx = 0L; var sy = 0L; var n = 0
        val step = 6
        var y = (h * 0.12).toInt()
        while (y < h * 0.9) {
            var x = (w * 0.2).toInt()
            while (x < w * 0.8) {
                px(buf, w, h, rowStride, pixelStride, x, y, c)
                if (isBand(c[0], c[1], c[2])) { sx += x; sy += y; n++ }
                x += step
            }
            y += step
        }
        if (n < 80) return null
        val cx = (sx / n).toInt(); val cy = (sy / n).toInt()
        // 2) raios
        val es = ArrayList<Double>(); val ws = ArrayList<Double>()
        val rmax = (min(w, h) * 0.55).toInt()
        for (k in 0 until RAYS) {
            val a = 2 * PI * k / RAYS; val ca = cos(a); val sa = sin(a)
            var bi = -1; var bo = -1; var rs = 0.0; var rn = 0
            var r = 6
            while (r < rmax) {
                val x = (cx + ca * r).toInt(); val yy = (cy + sa * r * 0.62).toInt() // elipse (perspectiva)
                if (x < 0 || yy < 0 || x >= w || yy >= h) break
                px(buf, w, h, rowStride, pixelStride, x, yy, c)
                if (isBand(c[0], c[1], c[2])) { if (bi < 0) bi = r; bo = r }
                else if (isRing(c[0], c[1], c[2])) { rs += r; rn++ }
                r += 2
            }
            if (bi < 0 || bo - bi < 8 || rn == 0) continue
            val width = (bo - bi).toDouble()
            // anel: considera so os pixels perto da faixa (ignora aro decorativo externo)
            var rs2 = 0.0; var rn2 = 0
            r = max(6, bi - (width * 0.6).toInt())
            while (r < bo + (width * 0.6)) {
                val x = (cx + ca * r).toInt(); val yy = (cy + sa * r * 0.62).toInt()
                if (x < 0 || yy < 0 || x >= w || yy >= h) break
                px(buf, w, h, rowStride, pixelStride, x, yy, c)
                if (isRing(c[0], c[1], c[2])) { rs2 += r; rn2++ }
                r += 2
            }
            if (rn2 == 0) continue
            es.add(((bi + bo) / 2.0 - rs2 / rn2) / width); ws.add(width)
        }
        if (es.size < 6) return null
        es.sort(); ws.sort()
        return Measure(es[es.size / 2], ws[ws.size / 2], cx, cy)
    }
}
