package com.manabot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }.also { col.addView(it) }
        col.addView(TextView(this).apply { text = "Mana Control Bot\n\n1) Permitir sobreposicao\n2) Ativar o servico de acessibilidade 'Mana Control Bot'\n3) Iniciar, abrir o Roblox e entrar no mini game.\nToque no texto BOT ON/OFF para pausar."; textSize = 16f })
        btn("1) Permissao de sobreposicao") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2) Abrir acessibilidade") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3) Iniciar bot") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
            startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), 1)
        }
        btn("Parar bot") { stopService(Intent(this, CaptureService::class.java)) }
        setContentView(col)
    }
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        if (rq == 1 && rs == RESULT_OK && d != null)
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", rs).putExtra("data", d))
    }
}
