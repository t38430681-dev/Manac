package com.manabot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Mantem um toque continuo (segurar) ou o libera. Usa strokes encadeados (willContinue). */
class TouchService : AccessibilityService() {
    companion object {
        @Volatile var instance: TouchService? = null
        @Volatile var holdX = 0f
        @Volatile var holdY = 0f
    }
    @Volatile private var want = false
    private var stroke: GestureDescription.StrokeDescription? = null
    private var busy = false
    private val SEG = 40L

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { want = false; stroke = null; busy = false }
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun setHold(hold: Boolean) {
        want = hold
        if (!busy) pump()
    }

    @Synchronized private fun pump() {
        val path = Path().apply { moveTo(holdX, holdY) }
        val cur = stroke
        val next: GestureDescription.StrokeDescription = when {
            cur == null && want -> GestureDescription.StrokeDescription(path, 0, SEG, true)
            cur != null && want -> cur.continueStroke(path, 0, SEG, true)
            cur != null && !want -> cur.continueStroke(path, 0, 1, false)
            else -> return
        }
        stroke = if (want) next else null
        busy = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(next).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { busy = false; if (want || stroke != null) pump() }
                override fun onCancelled(g: GestureDescription?) { busy = false; stroke = null; if (want) pump() }
            }, null)
        if (!ok) { busy = false; stroke = null }
    }
}
