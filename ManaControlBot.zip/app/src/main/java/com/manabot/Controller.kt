package com.manabot

import kotlin.math.abs

/**
 * Controlador adaptativo (mesmo algoritmo de sim/simulate.py).
 * e = (centro da faixa - anel alvo) / largura da faixa.  e>0 => precisa SEGURAR (encolhe).
 * - Aprende online as velocidades segurando (vH<0) e soltando (vR>0).
 * - Preve o erro pela latencia do toque e gera um duty-cycle (sigma-delta) em 60 Hz.
 * - Surtos (saltos bruscos) sao detectados e nao contaminam o aprendizado; satura ate recuperar.
 */
class Controller(var latency: Double = 0.05) {
    var vH = -0.9; private set
    var vR = 0.6; private set
    private var ve = 0.0
    private var acc = 0.0
    private var last: Double? = null
    var cmd = 0; private set
    var kp = 7.0

    fun reset() { last = null; ve = 0.0; acc = 0.0; cmd = 0 }

    fun step(dt: Double, eRaw: Double): Boolean {
        val e = eRaw
        last?.let { l ->
            val v = (e - l) / dt
            ve = 0.6 * ve + 0.4 * v
            if (abs(v) < 4) {
                if (cmd == 1) vH += 0.02 * (v - vH) else vR += 0.02 * (v - vR)
                vH = minOf(vH, -0.15); vR = maxOf(vR, 0.15)
            }
        }
        last = e
        val ep = e + ve * latency
        val vstar = -kp * ep
        var duty = ((vstar - vR) / (vH - vR)).coerceIn(0.0, 1.0)
        if (abs(e) > 0.55) duty = if (e > 0) 1.0 else 0.0
        acc += duty
        if (acc >= 1.0) { acc -= 1.0; cmd = 1 } else cmd = 0
        return cmd == 1
    }
}
