package com.manabot

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView

/** Captura a tela, mede o anel, roda o controlador a ~60 Hz e comanda o toque. */
class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var overlay: TextView? = null
    private val ctl = Controller()
    private var active = true
    private var lastT = 0L
    private var lost = 0
    private var okFrames = 0L; private var inZone = 0L

    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "bot"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Bot", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("Mana Control Bot ativo")
            .setSmallIcon(android.R.drawable.ic_media_play).build(),
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val code = i!!.getIntExtra("code", 0)
        val data = i.getParcelableExtra<Intent>("data")!!
        projection = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, null)
        val dm = resources.displayMetrics
        TouchService.holdX = dm.widthPixels * 0.70f; TouchService.holdY = dm.heightPixels * 0.66f
        val scale = 0.5f
        val w = (dm.widthPixels * scale).toInt(); val h = (dm.heightPixels * scale).toInt()
        thread = HandlerThread("vision").also { it.start() }
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection!!.createVirtualDisplay("cap", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null)
        reader!!.setOnImageAvailableListener({ r -> onFrame(r, w, h) }, Handler(thread!!.looper))
        showOverlay()
        return START_NOT_STICKY
    }

    private fun onFrame(r: ImageReader, w: Int, h: Int) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtimeNanos()
            val dt = if (lastT == 0L) 1 / 60.0 else ((now - lastT) / 1e9).coerceIn(0.005, 0.1)
            lastT = now
            if (!active) { TouchService.instance?.setHold(false); return }
            val p = img.planes[0]
            val m = Vision.measure(p.buffer, w, h, p.rowStride, p.pixelStride)
            if (m == null) {
                if (++lost > 10) { ctl.reset(); TouchService.instance?.setHold(false) }
                return
            }
            lost = 0
            val hold = ctl.step(dt, m.e)
            TouchService.instance?.setHold(hold)
            okFrames++; if (kotlin.math.abs(m.e) < 0.25) inZone++
            if (okFrames % 15 == 0L) overlay?.post {
                overlay?.text = "BOT ${if (active) "ON" else "OFF"}  e=${"%.2f".format(m.e)}  centro ${"%.0f".format(100.0 * inZone / okFrames)}%"
            }
        } finally { img.close() }
    }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val tv = TextView(this).apply {
            text = "BOT ON"; setTextColor(Color.WHITE); setBackgroundColor(0xAA000000.toInt()); setPadding(16, 8, 16, 8)
            setOnClickListener { active = !active; text = "BOT ${if (active) "ON" else "OFF"}"; ctl.reset() }
        }
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 8; y = 120 }
        getSystemService(WindowManager::class.java).addView(tv, lp); overlay = tv
    }

    override fun onDestroy() {
        TouchService.instance?.setHold(false)
        overlay?.let { getSystemService(WindowManager::class.java).removeView(it) }
        reader?.close(); projection?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
}
