# Mana Control Bot (Android)

Joga sozinho o mini game "Mana Control" do Roblox: captura a tela, mede a faixa clara (zona) e o anel lavanda,
e comanda SEGURAR/SOLTAR para manter o anel no meio da faixa.

## Como funciona
- `Vision.kt`: acha o centro pela cor da faixa (~RGB 182,142,183), lanca 36 raios e calcula
  e = (centro da faixa - anel) / largura da faixa (mediana dos raios; invariante a perspectiva e a surtos de tamanho).
- `Controller.kt`: aprende online as velocidades segurando/soltando, preve o erro pela latencia do toque,
  gera duty-cycle (sigma-delta ~60 Hz) e satura apos "surtos" (saltos bruscos de tamanho).
- `TouchService.kt`: toque continuo via Acessibilidade (strokes encadeados de 40 ms).
- `sim/simulate.py`: simulador (surtos, latencia, ruido). Resultado: ~99,9% dentro da zona e ~99,2% na metade central em regime
  estavel; ~96,7% contando a recuperacao imediata apos cada surto.

## Uso
1. Instale o APK (aba Actions > artefato `ManaControlBot-apk`).
2. Permita sobreposicao; ative o servico de acessibilidade "Mana Control Bot".
3. "Iniciar bot", abra o Roblox no mini game. Toque no texto flutuante para pausar.

## Ajustes
- Ponto do toque: `TouchService.holdX/holdY` (padrao 70% x 66% da tela; qualquer area vazia serve).
- Se o sinal do erro vier invertido no seu jogo, troque o sinal de `e` em `Vision.kt`.
- Cores: `isBand`/`isRing` em `Vision.kt`.
